readme.txt for the level editor

1.name of map
2.number of backgrounds
3.
  a) names of backgrounds (*.bmp files please and if possible with full path)
  b) eop

4.number of impassable zones
5. a)background number
   b) x
   c) y
   d)height
   e)width
   f)kind of object
   g)eop
...

